/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paramconverters;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Djordje
 */
@Provider
public class StringToDateConverterProvider implements ParamConverterProvider {

    @Override
    public <T> ParamConverter<T> getConverter(Class<T> rawType, Type type1, Annotation[] antns) {
        if (rawType.getName().equals(Date.class.getName())) {
            return new ParamConverter<T>() {
                @Override
                public T fromString(String value) {
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd-HH:mm:ss");
                        Date date = sdf.parse(value);
                        return rawType.cast(date);
                    } catch (ParseException ex) {
                        Logger.getLogger(StringToDateConverterProvider.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    return null;
                }

                @Override
                public String toString(T value) {
                    if (value != null) {
                        return value.toString();
                    }
                    return null;
                }
            };
        }
        return null;
    }
    
}
