/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package endpoints;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import entities.Plan;
import entities.User;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Djordje
 */
@Path("planner")
public class Planner {
    
    @Resource(lookup = "RequestTopic")
    private Topic topic;
    @Resource(lookup = "PlannerEndpointQueue")
    private Queue queue;
    @Resource(lookup = "jms/__defaultConnectionFactory")
    private ConnectionFactory connectionFactory;
    
    @PersistenceContext
    private EntityManager em;
    
    @GET
    @Path("ping")
    public Response ping() {
        return Response.ok("ping").build();
    }

    @GET
    @Path("list_plans/{username}")
    public Response listPlans(@PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            User user = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getSingleResult();
            long id_user = user.getId();
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "planner");
            textMessage.setStringProperty("ACTION", "LIST_PLANS");
            textMessage.setLongProperty("USER_ID", id_user);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof ObjectMessage) {
                context.close();
                ObjectMessage response = (ObjectMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                
                if ("SUCCESS".equals(mes)) {
                    List<String> list = (List<String>) response.getObject();
                    String stringList = "";
                    for (String p : list) {
                        stringList += p;
                        stringList += "-";
                    }
                    return Response.status(Response.Status.OK).entity(stringList).build();
                } else {
                    return Response.status(Response.Status.NOT_FOUND).entity(mes).build();
                }
            }
        } catch (JMSException ex) {
            Logger.getLogger(Alarm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("ERROR OCCURED").build();
    }
    
    @POST
    @Path("create_plan/{datetime}/{name}/{destination}/{duration}/{set_alarm}/{sound}/{period}/{username}")
    public Response createPlan(@PathParam("datetime") Date datetime, @PathParam("name") String name, @PathParam("destination") String destination, @PathParam("duration") long duration, 
            @PathParam("set_alarm") boolean set_alarm, @PathParam("sound") String sound, @PathParam("period") int period, @PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            User user = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getSingleResult();
            long id_user = user.getId();
            
            String origin = "";
            TypedQuery<Plan> fetchPlansQuery = em.createQuery("SELECT p FROM Plan p WHERE p.user = :user ORDER BY p.time ASC", Plan.class);
            fetchPlansQuery.setParameter("user", user);
            List<Plan> plans = fetchPlansQuery.getResultList();
            long current_time = datetime.getTime();
            for (Plan plan : plans) {
                if (plan.getTime().getTime() <= current_time) {
                    origin = plan.getDestination();
                } else {
                    break;
                }
            }
            
            if (origin.equals(""))
                origin = user.getPlace();
            
            name = name.replace("+", " ");
            if (destination.equals("-")) {
                destination = user.getPlace();
            } else {
                destination = destination.replace("+", " ");
            }
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "planner");
            textMessage.setStringProperty("ACTION", "CREATE_PLAN");
            textMessage.setLongProperty("TIME", datetime.getTime());
            textMessage.setStringProperty("NAME", name);
            textMessage.setStringProperty("ORIGIN", origin);
            textMessage.setStringProperty("DESTINATION", destination);
            textMessage.setLongProperty("DURATION", duration);
            textMessage.setBooleanProperty("SET_ALARM", set_alarm);
            textMessage.setStringProperty("SOUND", sound);
            textMessage.setIntProperty("PERIOD", period);
            textMessage.setLongProperty("USER_ID", id_user);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                TextMessage response = (TextMessage) message;
                context.close();
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return Response.status(Response.Status.CREATED).entity(mes).build();
                else 
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(mes).build();
            }
        } catch (JMSException ex) {
            Logger.getLogger(Alarm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("ERROR OCCURED").build();
    }
    
    @PUT
    @Path("change_plan/{id_plan}/{datetime}/{name}/{destination}/{duration}/{set_alarm}/{sound}/{period}/{id_user}")
    public Response changePlan(@PathParam("id_plan") long id_plan, @PathParam("datetime") Date datetime, @PathParam("name") String name, @PathParam("destination") String destination, @PathParam("duration") long duration, 
            @PathParam("set_alarm") boolean set_alarm, @PathParam("sound") String sound, @PathParam("period") int period, @PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            User user = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getSingleResult();
            long id_user = user.getId();
            
            TypedQuery<Plan> query = em.createQuery("SELECT p FROM Plan p WHERE p.id = :id AND p.user = :user ORDER BY p.time ASC", Plan.class).setParameter("user", user).setParameter("id", id_plan);
            List<Plan> plans = query.getResultList();
            
            if (plans.size() == 0) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("THIS PLAN FOR THIS USER DOESN'T EXIST").build();
            }
            
            String origin = "";
            long current_time = datetime.getTime();
            for (Plan plan : plans) {
                if (plan.getTime().getTime() <= current_time) {
                    origin = plan.getDestination();
                } else {
                    break;
                }
            }
            
            if (origin.equals(""))
                origin = user.getPlace();
            
            name = name.replace("+", " ");
            if (destination.equals("-")) {
                destination = user.getPlace();
            } else {
                destination = destination.replace("+", " ");
            }
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "planner");
            textMessage.setStringProperty("ACTION", "CHANGE_PLAN");
            
            textMessage.setLongProperty("ID", id_plan);
            textMessage.setLongProperty("TIME", datetime.getTime());
            textMessage.setStringProperty("NAME", name);
            textMessage.setStringProperty("ORIGIN", origin);
            textMessage.setStringProperty("DESTINATION", destination);
            textMessage.setLongProperty("DURATION", duration);
            textMessage.setBooleanProperty("SET_ALARM", set_alarm);
            textMessage.setStringProperty("SOUND", sound);
            textMessage.setIntProperty("PERIOD", period);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return Response.status(Response.Status.OK).entity(mes).build();
                else 
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(mes).build();
            }
        } catch (JMSException ex) {
            Logger.getLogger(Alarm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("ERROR OCCURED").build();
    }
    
    @DELETE
    @Path("delete_plan/{id_plan}/{username}")
    public Response removePlan(@PathParam("id_plan") int id_plan, @PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            User user = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getSingleResult();
            
            TypedQuery<Plan> query = em.createQuery("SELECT p FROM Plan p WHERE p.id = :id AND p.user = :user", Plan.class);
            query.setParameter("id", id_plan);
            query.setParameter("user", user);
            List<Plan> plans = query.getResultList();
            
            if (plans.size() == 0) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("PLAN FOR THIS USER DOESN'T EXIST").build();
            }
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "planner");
            textMessage.setStringProperty("ACTION", "REMOVE_PLAN");
            textMessage.setLongProperty("ID", id_plan);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return Response.status(Response.Status.OK).entity(mes).build();
                else 
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(mes).build();
            }
            
        } catch (JMSException ex) {
            Logger.getLogger(Alarm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("ERROR OCCURED").build();
    }
}
