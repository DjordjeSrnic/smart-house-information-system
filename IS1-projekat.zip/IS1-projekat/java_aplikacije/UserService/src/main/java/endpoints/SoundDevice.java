/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package endpoints;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import entities.User;
/**
 *
 * @author Djordje
 */
@Path("sounddevice")
public class SoundDevice {
    
    @Resource(lookup = "RequestTopic")
    private Topic topic;
    @Resource(lookup = "SoundDeviceEndpointQueue")
    private Queue queue;
    @Resource(lookup = "jms/__defaultConnectionFactory")
    private ConnectionFactory connectionFactory;
    
    @PersistenceContext
    private EntityManager em;
    
    @POST
    @Path("play_song/{song}/{username}")
    public Response playSong(@PathParam("song") String song, @PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            
            User user = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getSingleResult();
            long id_user = user.getId();
            
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "sound_device");
            textMessage.setStringProperty("ACTION", "PLAY_SONG");
            textMessage.setStringProperty("SONG", song);
            textMessage.setLongProperty("USER_ID", id_user);
            producer.send(topic, textMessage);
          
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return Response.status(Response.Status.CREATED).entity(mes).build();
                else 
                    return Response.status(Response.Status.CREATED).entity(mes).build();
            }
        } catch (JMSException ex) {
            Logger.getLogger(SoundDevice.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.CREATED).entity("ERROR OCCURED").build();
    }
    
    @GET
    @Path("list_songs/{username}")
    public Response listSongs(@PathParam("username") String username) {
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(queue);
            JMSProducer producer = context.createProducer();
            
            List<User> users = em.createNamedQuery("User.findByUsername", User.class).setParameter("username", username).getResultList();
            long id_user = users.get(0).getId();
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "sound_device");
            textMessage.setStringProperty("ACTION", "LIST_SONGS");
            textMessage.setLongProperty("USER_ID", id_user);
            producer.send(topic, textMessage);
            
            System.out.println("NOT RECEIVED");
            Message message = consumer.receive();
            System.out.println("RECEIVED");
            if (message instanceof ObjectMessage) {
                context.close();
                ObjectMessage response = (ObjectMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                
                if ("SUCCESS".equals(mes)) {
                    String list = (String) response.getObject();
                    return Response.status(Response.Status.OK).entity(list).build();
                } else {
                    return Response.status(Response.Status.NOT_FOUND).entity(mes).build();
                }
            }
        } catch (JMSException ex) {
            Logger.getLogger(Alarm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("ERROR OCCURED").build();
    }
}
