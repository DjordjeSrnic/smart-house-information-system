/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planner;

import entities.Alarm;
import entities.Plan;
import entities.User;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.core.Response;
import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author Djordje
 */
public class Main {

    @Resource(lookup = "RequestTopic")
    static Topic topic;
    @Resource(lookup = "PlannerEndpointQueue")
    static Queue queue;
    @Resource(lookup = "PlannerResponseQueue")
    static Queue response_queue;
    @Resource(lookup = "jms/__defaultConnectionFactory")
    static ConnectionFactory connectionFactory;
    
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("PlannerPU");
    private static EntityManager em;
    
    public static void main(String[] args) throws JMSException {
        JMSContext context = connectionFactory.createContext();
        JMSConsumer consumer = context.createConsumer(topic, "FOR = 'planner'", false);
        JMSProducer producer = context.createProducer();
        em = emf.createEntityManager();
        //em.setFlushMode(FlushModeType.COMMIT);
        
        while(true) {
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String action = textMessage.getStringProperty("ACTION");
                System.out.println("REQUEST RECEIVED " + action);
                switch(action) {
                    case "LIST_PLANS": {
                        long id_user = textMessage.getLongProperty("USER_ID");
                        
                        TypedQuery<User> fetchUserQuery = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                        fetchUserQuery.setParameter("user", id_user);
                        User user = fetchUserQuery.getSingleResult();
                        
                        em.getTransaction().begin();
                        TypedQuery<Plan> query = em.createQuery("SELECT p FROM Plan p WHERE p.user = :user", Plan.class);
                        query.setParameter("user", user);
                        List<Plan> results = query.getResultList();
                        List<String> planStringList = new ArrayList<>();
                        for(Plan p: results) {
                            planStringList.add(p.toString());
                        }
                        em.getTransaction().commit();
                        
                        
                        ObjectMessage objectMessage = context.createObjectMessage();
                        objectMessage.setObject((Serializable) planStringList);
                        objectMessage.setStringProperty("RESPONSE", "SUCCESS");
                        producer.send(queue, objectMessage);
                        break;
                    }
                    case "CREATE_PLAN": {
                        Date time = new Date(textMessage.getLongProperty("TIME"));
                        String name = textMessage.getStringProperty("NAME");
                        String origin = textMessage.getStringProperty("ORIGIN");
                        String destination = textMessage.getStringProperty("DESTINATION");
                        Long duration = textMessage.getLongProperty("DURATION");
                        boolean toSetAlarm = textMessage.getBooleanProperty("SET_ALARM");
                        long id_user = textMessage.getLongProperty("USER_ID");
                        
                        TypedQuery<User> fetchUserQuery = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                        fetchUserQuery.setParameter("user", id_user);
                        User user = fetchUserQuery.getSingleResult();
                        
                        if (checkForOverlap(time, duration, user)) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "OVERLAP");
                            producer.send(queue, response);
                            break;
                        }
                        
                        long travel_time = 0;
                        if (!origin.equals(destination)) {
                            travel_time = Travel.getTravelTime(origin, destination);
                        }
                        
                        long trip_start_time = time.getTime() - travel_time;
                            
                        if (checkForOverlap(new Date(trip_start_time), travel_time, user)) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "OVERLAP ALARM");
                            producer.send(queue, response);
                            break;
                        }
  
                        if (toSetAlarm) {
                            String sound = textMessage.getStringProperty("SOUND");
                            int period = textMessage.getIntProperty("PERIOD");
                            System.out.println("SETTING ALARM");
                            boolean isSet = setAlarm(trip_start_time, sound, period, id_user);
                            if (isSet)
                                System.out.println("ALARM SET");
                            else
                                System.out.println("ALARM NOT SET");
                        }
                        
                        em.getTransaction().begin();
                        em.flush();
                        em.clear();
                        em.getTransaction().commit();
                        
                        TypedQuery<Alarm> query = em.createNamedQuery("Alarm.findAll", Alarm.class);
                        List<Alarm> resultList = query.setHint(QueryHints.REFRESH, true).getResultList();
                        System.out.println("ALARMS SIZE: " + resultList.size());
                        Alarm alarm = null;
                        if (resultList.size() > 0) {
                            long max_id = 0;
                            for(int i=0;i<resultList.size();i++) {
                                if (resultList.get(i).getId()>max_id)
                                    max_id = resultList.get(i).getId();
                                    alarm = resultList.get(i);
                            }
                        }
                        
                        
                        em.getTransaction().begin();
                        Plan plan = new Plan();
                        plan.setName(name);
                        plan.setTime(time);
                        plan.setOrigin(origin);
                        plan.setDestination(destination);
                        plan.setDuration(duration);
                        plan.setUser(user);
                        if (toSetAlarm)
                            plan.setAlarm(alarm);
                        em.persist(plan);
                        em.getTransaction().commit();
                        
                        TextMessage response = context.createTextMessage();
                        response.setStringProperty("RESPONSE", "SUCCESS");
                        producer.send(queue, response);
                        break;
                    }
                    case "CHANGE_PLAN": {
                        long id = textMessage.getLongProperty("ID");
                        Date time = new Date(textMessage.getLongProperty("TIME"));
                        String name = textMessage.getStringProperty("NAME");
                        String origin = textMessage.getStringProperty("ORIGIN");
                        String destination = textMessage.getStringProperty("DESTINATION");
                        long duration = textMessage.getLongProperty("DURATION");
                        String sound = textMessage.getStringProperty("SOUND");
                        int period = textMessage.getIntProperty("PERIOD");
                        boolean toSetAlarm = textMessage.getBooleanProperty("SET_ALARM");
                        long id_user = textMessage.getLongProperty("USER_ID");
                        
                        Plan plan = em.find(Plan.class, id);
                        
                        TypedQuery<User> fetchUserQuery = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                        fetchUserQuery.setParameter("user", id_user);
                        User user = fetchUserQuery.getSingleResult();
                        
                        if (plan == null) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "NOT FOUND");
                            producer.send(queue, response);
                            break;
                        }
                        
                        if (checkForOverlap(time, duration, user)) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "FAILURE");
                            producer.send(queue, response);
                            break;
                        }
                        
                        long travel_time = 0;
                        if (!origin.equals(destination)) {
                            travel_time = Travel.getTravelTime(origin, destination);
                        }
                        
                        long trip_start_time = time.getTime() - travel_time;
                            
                        if (checkForOverlap(new Date(trip_start_time), travel_time, user)) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "OVERLAP ALARM");
                            producer.send(queue, response);
                            break;
                        }
                        
                        if (toSetAlarm) {
                            if (plan.getAlarm() == null)
                                setAlarm(trip_start_time, sound, period, id_user);
                            else
                                updateAlarm(plan.getAlarm().getId(), trip_start_time, sound, period);
                        } else {
                            if (plan.getAlarm() != null){
                                removeAlarm(plan.getAlarm().getId());
                            }
                        }
                        
                        Alarm alarm = null;
                        if (toSetAlarm && plan.getAlarm() == null) {
                            em.getTransaction().begin();
                            TypedQuery<Alarm> query = em.createQuery("SELECT a FROM Alarm a ORDER BY a.id ASC", Alarm.class);
                            List<Alarm> resultList = query.getResultList();
                            em.getTransaction().commit();
                            if (resultList.size() > 0) 
                                alarm = resultList.get(resultList.size()-1);
                        }
                        

                        em.getTransaction().begin();
                        plan.setTime(time);
                        plan.setName(name);
                        plan.setOrigin(origin);
                        plan.setDestination(destination);
                        plan.setDuration(duration);
                        if (toSetAlarm && plan.getAlarm() == null)
                            plan.setAlarm(alarm);
                        em.getTransaction().commit();
                        
                        TextMessage response = context.createTextMessage();
                        response.setStringProperty("RESPONSE", "SUCCESS");
                        producer.send(queue, response);
                        break;
                    }
                    case "REMOVE_PLAN": {
                        long id = textMessage.getLongProperty("ID");
                        Plan plan = em.find(Plan.class, id);
                        
                        long alarmID = -1;
                        if (plan == null) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "NOT FOUND");
                            producer.send(queue, response);
                        } else {
                            alarmID = plan.getAlarm().getId();
                            em.getTransaction().begin();
                            Query query = em.createQuery("DELETE FROM Plan p WHERE p.id = :id");
                            query.setParameter("id", id).executeUpdate();
                            em.getTransaction().commit();
                            
                            if (alarmID != -1) {
                                removeAlarm(alarmID);
                            }
                            
                            System.out.println("REMOVED AN ALARM");
                            
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "SUCCESS");
                            producer.send(queue, response);
                        }
                        
                        break;
                    }
                }
            }
        }
    }
    
    private static boolean setAlarm(long alarm_time, String sound, int period, long id_user) {      
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(response_queue);
            JMSProducer producer = context.createProducer();
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "alarm");
            textMessage.setStringProperty("FROM", "PLANNER");
            textMessage.setStringProperty("ACTION", "SET_ALARM");
            textMessage.setLongProperty("TIME", alarm_time);
            textMessage.setIntProperty("PERIOD", period);
            textMessage.setStringProperty("SOUND", sound);
            textMessage.setLongProperty("USER_ID", id_user);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                System.out.println("MESSAGE: " + mes);
                if ("SUCCESS".equals(mes)) {
                    System.out.println("SUCCESS");
                    return true;
                } else 
                    return false;
            }
        } catch (JMSException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    private static boolean updateAlarm(long id, long alarm_time, String sound, int period) {      
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(response_queue);
            JMSProducer producer = context.createProducer();
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "alarm");
            textMessage.setStringProperty("FROM", "PLANNER");
            textMessage.setStringProperty("ACTION", "UPDATE_ALARM");
            textMessage.setLongProperty("ID", id);
            textMessage.setLongProperty("TIME", alarm_time);
            textMessage.setIntProperty("PERIOD", period);
            textMessage.setStringProperty("SOUND", sound);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return true;
                else 
                    return false;
            }
        } catch (JMSException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    private static boolean removeAlarm(long alarmID) {      
        try {
            JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer = context.createConsumer(response_queue);
            JMSProducer producer = context.createProducer();
            
            TextMessage textMessage = context.createTextMessage();
            textMessage.setStringProperty("FOR", "alarm");
            textMessage.setStringProperty("FROM", "PLANNER");
            textMessage.setStringProperty("ACTION", "REMOVE_ALARM");
            textMessage.setLongProperty("ID", alarmID);
            producer.send(topic, textMessage);
            
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                context.close();
                TextMessage response = (TextMessage) message;
                String mes = response.getStringProperty("RESPONSE");
                if ("SUCCESS".equals(mes))
                    return true;
                else 
                    return false;
            }
        } catch (JMSException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    private static boolean checkForOverlap(Date datetime, long duration, User user) {
        TypedQuery<Plan> query = em.createQuery("SELECT p FROM Plan p WHERE p.user = :user", Plan.class);
        query.setParameter("user", user);
        List<Plan> results = query.getResultList();
        for(Plan p: results) {
            long start = p.getTime().getTime();
            long end = p.getTime().getTime() + p.getDuration();
            boolean case1 = datetime.getTime() <= start && datetime.getTime()+duration >= end;
            boolean case2 = datetime.getTime() >= start && datetime.getTime()+duration <= end;
            boolean case3 = datetime.getTime() <= start && datetime.getTime()+duration <= end && datetime.getTime()+duration >= start;
            boolean case4 = datetime.getTime() >= start && datetime.getTime() <= end && datetime.getTime()+duration >= end;
            
            if (case1 || case2 || case3 || case4)
                return true;
        }
        
        return false;
    }
}
