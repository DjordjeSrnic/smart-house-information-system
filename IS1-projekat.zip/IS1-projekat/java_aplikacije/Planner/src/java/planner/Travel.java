/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planner;

import com.mapbox.api.directions.v5.DirectionsCriteria;
import com.mapbox.api.directions.v5.models.DirectionsResponse;
import com.mapbox.api.geocoding.v5.MapboxGeocoding;
import com.mapbox.api.geocoding.v5.models.GeocodingResponse;
import com.mapbox.api.matrix.v1.MapboxMatrix;
import com.mapbox.api.matrix.v1.models.MatrixResponse;
import com.mapbox.geojson.Point;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 *
 * @author Djordje
 */
public class Travel {
    
    public static long getTravelTime(String origin, String destination) {
        try {
            MapboxGeocoding mg = MapboxGeocoding.builder()
                    .accessToken("pk.eyJ1Ijoic3JuMTQyIiwiYSI6ImNrOWVpNnJkeTAyMzYzb3MwMWQ3dnNhNXAifQ.yZOsODPIDPt5Fu3AazhDog")
                    .query(origin)
                    .build();
            
            Response<GeocodingResponse> res = mg.executeCall();
            double lng1 = res.body().features().get(0).bbox().north();
            double lat1 = res.body().features().get(0).bbox().east();
            System.out.println("("+ lng1 + "," + lat1 + ")");
            
            mg = MapboxGeocoding.builder()
                    .accessToken("pk.eyJ1Ijoic3JuMTQyIiwiYSI6ImNrOWVpNnJkeTAyMzYzb3MwMWQ3dnNhNXAifQ.yZOsODPIDPt5Fu3AazhDog")
                    .query(destination)
                    .build();
            
            res = mg.executeCall();
            double lng2 = res.body().features().get(0).bbox().north();
            double lat2 = res.body().features().get(0).bbox().east();
            System.out.println("("+ lng2 + "," + lat2 + ")");
            
            MapboxMatrix mat = MapboxMatrix.builder()
                    .accessToken("pk.eyJ1Ijoic3JuMTQyIiwiYSI6ImNrOWVpNnJkeTAyMzYzb3MwMWQ3dnNhNXAifQ.yZOsODPIDPt5Fu3AazhDog")
                    .profile(DirectionsCriteria.PROFILE_DRIVING)
                    .coordinate(Point.fromLngLat(lng1, lat1))
                    .coordinate(Point.fromLngLat(lng2, lat2))
                    .build();
            
            Response<MatrixResponse> matRes = mat.executeCall();
            double duration = matRes.body().durations().get(0)[1];
            
            return Math.round(duration)*1000;
        } catch (IOException ex) {
            Logger.getLogger(Travel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return -1;
    }
}
