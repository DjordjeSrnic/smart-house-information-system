/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alarm;

import entities.Alarm;
import entities.User;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author Djordje
 */
public class Main {

    @Resource(lookup = "RequestTopic")
    static Topic topic;
    @Resource(lookup = "AlarmEndpointQueue")
    static Queue queue;
    @Resource(lookup = "PlannerResponseQueue")
    static Queue response_queue;
    @Resource(lookup = "jms/__defaultConnectionFactory")
    static ConnectionFactory connectionFactory;
    
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("AlarmPU");
    private static EntityManager em;
    
    static ArrayList<Timer> all_timers = new ArrayList<>();
    
    private static class MyTimerTask extends TimerTask {  

        private String name;

        public MyTimerTask(final String name) {
            this.name = name;
        }

        @Override
        public void run() {
            try {
                Clip clip = AudioSystem.getClip();
                AudioInputStream ais = AudioSystem.getAudioInputStream(new File(name));
                clip.open(ais);
                clip.start();
            } catch (LineUnavailableException | UnsupportedAudioFileException | IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public static void main(String[] args) throws JMSException {
        JMSContext context = connectionFactory.createContext();
        JMSConsumer consumer = context.createConsumer(topic, "FOR = 'alarm'", true);
        JMSProducer producer = context.createProducer();
        em = emf.createEntityManager();
        em.setFlushMode(FlushModeType.COMMIT);
        
        initTimers();
        
        while(true) {
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String action = textMessage.getStringProperty("ACTION");
                
                System.out.println("REQUEST RECEIVED " + action);
                
                switch(action){
                    case "SET_ALARM": {
                        String from = textMessage.getStringProperty("FROM");
                        long time = textMessage.getLongProperty("TIME");
                        long id_user = textMessage.getLongProperty("USER_ID");
                        Date alarm_time = new Date(time);
                        
                        int period = textMessage.getIntProperty("PERIOD");
                        
                        String sound = textMessage.getStringProperty("SOUND");
                        
                        System.out.println(alarm_time);
                        
                        if (alarm_time.getTime() <= (new Date()).getTime()) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "FAILURE");
                            if (from != null) {
                                producer.send(response_queue, response);
                            } else
                                producer.send(queue, response);
                            break;
                        }
                        
                        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                        query.setParameter("user", id_user);
                        User user = query.getSingleResult();
                        
                        TypedQuery<Alarm> alarmFetchQuery = em.createQuery("SELECT a FROM Alarm a WHERE a.user = :user AND a.time = :time", Alarm.class);
                        alarmFetchQuery.setParameter("user", user);
                        alarmFetchQuery.setParameter("time", alarm_time);
                        List<Alarm> alarms = alarmFetchQuery.getResultList();
                        
                        if (alarms.size() > 0) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "ALARM ALREADY EXISTS");
                            if (from != null) {
                                producer.send(response_queue, response);
                            } else
                                producer.send(queue, response);
                            break;
                        }
                        
                        em.getTransaction().begin();
                        Alarm new_alarm = new Alarm();
                        new_alarm.setTime(alarm_time);
                        new_alarm.setPeriod(period);
                        new_alarm.setSound(sound);
                        new_alarm.setUser(user);
                        em.persist(new_alarm);
                        em.getTransaction().commit();
                        
                        System.out.println("NEW ALARM ID: " + new_alarm.getId());
                        
                        addTimer(new_alarm);
                        
                        TextMessage response = context.createTextMessage();
                        response.setStringProperty("RESPONSE", "SUCCESS");
                        if (from != null) {
                            System.out.println("RESPONSE WAS SENT TO PLANNER");
                            producer.send(response_queue, response);
                        } else
                            producer.send(queue, response);
                        break;
                    }
                    case "REMOVE_ALARM": {
                        String from = textMessage.getStringProperty("FROM");
                        long id = textMessage.getLongProperty("ID");
                        Alarm alarm = em.find(Alarm.class, id);
                        System.out.println("REMOVE ALARM");
                        
                        if (alarm == null) {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "FAILURE");
                            if (from != null)
                                producer.send(response_queue, response);
                            else
                                producer.send(queue, response);
                        } else {
                            em.getTransaction().begin();
                            Query query = em.createQuery("DELETE FROM Alarm a WHERE a.id = :id");
                            query.setParameter("id", id).executeUpdate();
                            em.getTransaction().commit();
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "SUCCESS");
                            System.out.println("FROM " + from);
                            if (from != null)
                                producer.send(response_queue, response);
                            else
                                producer.send(queue, response);
                            resetTimers();
                        }
                        break;
                    }
                    case "CHANGE_SOUND": {
                        long id = textMessage.getLongProperty("ID");
                        
                        String new_sound = textMessage.getStringProperty("SOUND");
                        
                        Alarm alarm = em.find(Alarm.class, id);
                        if (alarm != null) {
                            em.getTransaction().begin();
                            Query query = em.createQuery("UPDATE Alarm a SET a.sound = :sound WHERE a.id = :id");
                            query.setParameter("id", id).setParameter("sound", new_sound).executeUpdate();
                            em.getTransaction().commit();
                            resetTimers();
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "SUCCESS");
                            producer.send(queue, response);
                        } else {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "FAILURE");
                            producer.send(queue, response);
                        }
                        
                        break;
                    }
                    
                    case "UPDATE_ALARM": {
                        long id = textMessage.getLongProperty("ID");
                        
                        long time = textMessage.getLongProperty("TIME");
                        Date new_alarm_time = new Date(time);
                        
                        int new_period = textMessage.getIntProperty("PERIOD");
                        
                        String new_sound = textMessage.getStringProperty("SOUND");
                        
                        Alarm alarm = em.find(Alarm.class, id);
                        if (alarm != null) {
                            em.getTransaction().begin();
                            alarm.setPeriod(new_period);
                            alarm.setSound(new_sound);
                            alarm.setTime(new_alarm_time);
                            em.getTransaction().commit();
                            resetTimers();
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "SUCCESS");
                            producer.send(response_queue, response);
                        } else {
                            TextMessage response = context.createTextMessage();
                            response.setStringProperty("RESPONSE", "FAILURE");
                            producer.send(response_queue, response);
                        }
                        
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }
    
    private static void initTimers() {
        TypedQuery<Alarm> query = em.createQuery("SELECT a FROM Alarm a WHERE a.time > :date", Alarm.class);
        query.setParameter("date", new Date(), TemporalType.TIMESTAMP);
        List<Alarm> results = query.getResultList();
        for (Alarm a : results) {
            addTimer(a);
        }
    }
    
    private static void resetTimers() {
        for (Timer timer : all_timers) {
            timer.cancel();
        }
        all_timers.clear();
        initTimers();
    }
    
    private static void addTimer(Alarm alarm) {
        Timer timer = new Timer(true);
        String path = "C:/Users/Djordje/Documents/NetBeansProjects/Alarm/src/java/alarm/" + alarm.getSound();
        all_timers.add(timer);
        if (alarm.getPeriod() > 0) {
            timer.scheduleAtFixedRate(new MyTimerTask(path), alarm.getTime(), alarm.getPeriod() * 1000);
        } else {
            timer.schedule(new MyTimerTask(path), alarm.getTime());
        }
    }
}
