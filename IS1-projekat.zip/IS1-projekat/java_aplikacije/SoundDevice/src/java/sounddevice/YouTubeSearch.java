
package sounddevice;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.youtube.YouTube;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class YouTubeSearch {

    private static final String API_KEY = "AIzaSyD8tv7_9Wgf940W9W-tBmOZJhZOuLuAEq4";

    private static final long NUMBER_OF_VIDEOS_RETURNED = 1;

    private static YouTube youtube;

    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

    public static String search(String term) throws GeneralSecurityException, IOException {

        String keyword = term;
        keyword = keyword.replace(" ", "+");

        String url = "https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=" + keyword + "&key=AIzaSyD8tv7_9Wgf940W9W-tBmOZJhZOuLuAEq4";

        Document doc = Jsoup.connect(url).ignoreContentType(true).timeout(10 * 1000).get();

        String getJson = doc.text();
        System.out.println(getJson);
        JSONObject jsonObject = (JSONObject) new JSONTokener(getJson).nextValue();
        System.out.println(jsonObject.toString());
        JSONArray items = jsonObject.optJSONArray("items");
        JSONObject item = items.optJSONObject(items.length()-1);
        JSONObject idObject = (JSONObject) item.get("id");
        return idObject.getString("videoId");
    }
}
