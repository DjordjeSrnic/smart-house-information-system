/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sounddevice;

import com.google.api.services.youtube.model.SearchResult;
import entities.Song;
import entities.User;
import java.awt.Desktop;
import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.security.GeneralSecurityException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Djordje
 */
public class Main {

    @Resource(lookup = "jms/__defaultConnectionFactory")
    private static ConnectionFactory connectionFactory;
    @Resource(lookup = "SoundDeviceEndpointQueue")
    private static Queue queue;
    @Resource(lookup = "RequestTopic")
    private static Topic topic;
    
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("SoundDevicePU");
    private static EntityManager em;

    
    
    public static void main(String[] args) throws JMSException, GeneralSecurityException {
        JMSContext context = connectionFactory.createContext();
        JMSConsumer consumer = context.createConsumer(topic, "FOR = 'sound_device'", true);
        JMSProducer producer = context.createProducer();
        em = emf.createEntityManager();
        em.setFlushMode(FlushModeType.COMMIT);
        
        while(true) {
            Message message = consumer.receive();
            
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String action = textMessage.getStringProperty("ACTION");
                System.out.println("RECEIVED");
                switch(action) {
                    case "PLAY_SONG": {
                        playSong(textMessage.getStringProperty("SONG"), textMessage.getLongProperty("USER_ID"));
                        TextMessage response = context.createTextMessage();
                        response.setStringProperty("RESPONSE", "SUCCESS");
                        producer.send(queue, response);
                        break;
                    }
                    case "LIST_SONGS": {
                        em.getTransaction().begin();
                        
                        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                        query.setParameter("user", textMessage.getLongProperty("USER_ID"));
                        User user = query.getSingleResult();
                        
                        TypedQuery<String> fetchQuery = em.createQuery("SELECT s.name FROM Song s WHERE s.user = :user", String.class);
                        query.setParameter("user", user);
                        List<String> songsList = fetchQuery.getResultList();
                        em.getTransaction().commit();
                        JSONArray jsonArray = new JSONArray();
                        for(String name: songsList) {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("name", name);
                            jsonArray.put(jsonObject);
                        }
                        
                        ObjectMessage objectMessage = context.createObjectMessage();
                        objectMessage.setObject(jsonArray.toString());
                        objectMessage.setStringProperty("RESPONSE", "SUCCESS");
                        producer.send(queue, objectMessage);
                        System.out.println("RESPONSE SENT");
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }
    
    private static final String URL_START = "https://www.youtube.com/watch?v=";
    
    private static void playSong(String searchTerm, long id_user) throws GeneralSecurityException {
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            try {
                String firstResult = YouTubeSearch.search(searchTerm);
                final String url = URL_START + firstResult;
                Desktop.getDesktop().browse(URI.create(url));
                
                TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.id = :user", User.class);
                query.setParameter("user", id_user);
                User user = query.getSingleResult();
                
                TypedQuery<Song> findQuery = em.createQuery("SELECT s FROM Song s WHERE s.videoURL = :url AND s.user = :user", Song.class);
                findQuery.setParameter("url", url);
                findQuery.setParameter("user", user);
                List<Song> songs = findQuery.getResultList();
                
                if (songs.size() == 0) {
                    em.getTransaction().begin();
                    Song song = new Song();
                    song.setName(searchTerm);
                    song.setVideoURL(url);
                    song.setUser(user);
                    em.persist(song);
                    em.getTransaction().commit();
                }
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
