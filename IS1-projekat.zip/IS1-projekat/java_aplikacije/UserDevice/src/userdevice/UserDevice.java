/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdevice;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingWorker;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.ListModel;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Djordje
 */
public class UserDevice {

    public static void main(String[] args) {
       initGUI();
    }
    
    private static void initGUI() {
        JPanel soundDevicePanel = createSoundDevicePanel();
        JPanel alarmPanel = createAlarmPanel();
        JPanel plannerPanel = createPlannerPanel();
        
        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Sound Device", soundDevicePanel);
        tabs.add("Alarm", alarmPanel);
        tabs.add("Planner", plannerPanel);
        
        JFrame frame = new JFrame("User Device");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.add(tabs);
        frame.setSize(1024, 540);
        frame.setVisible(true);
        
    }
    
    private static JPanel createSoundDevicePanel() {
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.BLACK, 2));
        panel.setLayout(new GridLayout(3,1));
        
        JLabel errorLabel = new JLabel("");
        errorLabel.setForeground(Color.red);
        errorLabel.setFont(new Font("Courier", Font.BOLD,12));
        
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new GridLayout(4,1));
        userPanel.add(new JLabel("Username: "));
        JTextField username = new JTextField(50);
        JPasswordField password = new JPasswordField(50);
        userPanel.add(username);
        userPanel.add(new JLabel("Password: "));
        userPanel.add(password);

        JPanel functionPanel = new JPanel();
        functionPanel.setLayout(new GridLayout(4,1));
        
        DefaultListModel<String> songsListModel = new DefaultListModel<>();
        JList<String> songs = new JList<>(songsListModel);
        
        functionPanel.add(new JLabel("Search: "));

        JTextField songNameTextField = new JTextField(50);
        functionPanel.add(songNameTextField);

        JButton searchButton = new JButton("Search Song");
        searchButton.addActionListener((e) -> {
            try {
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                System.out.println(userCredentials);
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                
                String song_name = songNameTextField.getText().replace(" ", "+");
		URL url = new URL("http://localhost:8080/UserService/api/sounddevice/play_song/" + song_name + "/" + username.getText());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("POST");
                
		if (conn.getResponseCode() != 201) {
                    System.out.println("Failed to find a song");
                    errorLabel.setText("Failed to find a song");
                    
                    throw new RuntimeException("Failed : HTTP error code : "
                                    + conn.getResponseCode());
		}

                System.out.println("RESPONSE");
                System.out.println(conn.getResponseMessage());
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        functionPanel.add(searchButton);
        JPanel controlPanel = new JPanel();
        //controlPanel.setLayout();

        JButton historyButton = new JButton("All Songs");
        historyButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                
		URL url = new URL("http://localhost:8080/UserService/api/sounddevice/list_songs" + "/" + username.getText());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("GET");
                
		if (conn.getResponseCode() != 200) {
                        errorLabel.setText("Failed to fetch songs");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
                        
                }
                
                BufferedReader br = new BufferedReader(new InputStreamReader(
			(conn.getInputStream())));

		String output;
                String songsList = "";
                songsListModel.clear();
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
                    songsList = output;
                }
                JSONArray jsonArray = new JSONArray(songsList);
                
                for(int i=0;i<jsonArray.length();i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    songsListModel.addElement(jsonObject.getString("name"));
                }
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        functionPanel.add(historyButton);
        
        controlPanel.add(functionPanel, BorderLayout.NORTH);
        controlPanel.add(userPanel, BorderLayout.SOUTH);
        
        panel.add(controlPanel);
        panel.add(songs);
        panel.add(errorLabel);

        return panel;
    }
    
    private static JPanel createAlarmPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.BLACK, 2));
        panel.setLayout(new GridLayout(10,1));
        
        JLabel errorLabel = new JLabel("");
        errorLabel.setForeground(Color.red);
        errorLabel.setFont(new Font("Courier", Font.BOLD,12));
        
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new GridLayout(4,1));
        userPanel.add(new JLabel("Username: "));
        JTextField username = new JTextField(50);
        JPasswordField password = new JPasswordField(50);
        userPanel.add(username);
        userPanel.add(new JLabel("Password: "));
        userPanel.add(password);
        
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(1,3));
        DefaultListModel<String> alarmsListModel = new DefaultListModel<>();
        JList<String> alarmList = new JList<>(alarmsListModel);

        // CREATE ALARM PANEL
        JPanel createPanel = new JPanel();
        createPanel.setBorder(new LineBorder(Color.BLACK, 2));
        createPanel.setLayout(new GridLayout(7,1));
        createPanel.add(new JLabel("Date and Time:"));
        JSpinner timeSpinner = new JSpinner( new SpinnerDateModel() );
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "yyyy.MM.dd-HH:mm:ss");
        timeSpinner.setEditor(timeEditor);
        timeSpinner.setValue(new Date()); // will only show the current time
        timeSpinner.addChangeListener((ChangeEvent e) -> {
            try {
                if (((Date) timeSpinner.getValue()).before(new Date())) {
                    timeSpinner.setValue(new Date());
                    return;
                }
                timeSpinner.commitEdit();
            } catch (ParseException ex) {
                timeSpinner.setValue(new Date());
            }
        });
        createPanel.add(timeSpinner);
        createPanel.add(new JLabel("Period"));
        JTextField period = new JTextField(10);
        createPanel.add(period);
        createPanel.add(new JLabel("Sound"));
        String[] sounds = {"alarm1.wav", "alarm2.wav", "alarm3.wav"};
        JComboBox soundSelect = new JComboBox(sounds);
        createPanel.add(soundSelect);
        JButton createAlarmButton = new JButton("Add Alarm");
        createAlarmButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                params += Integer.parseInt(period.getText()) + "/";
                Date datetime = (Date)timeSpinner.getValue();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd-HH:mm:ss");  
                params += formatter.format(datetime) + "/";
                params += (String)soundSelect.getSelectedItem() + "/";
                params += username.getText();
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                
		URL url = new URL("http://localhost:8080/UserService/api/alarm/create_alarm/"+params);
                System.out.println("http://localhost:8080/UserService/api/alarm/create_alarm/"+params);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("POST");
                
		if (conn.getResponseCode() != 201) {
                        errorLabel.setText("Couldn't create an alarm");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        createPanel.add(createAlarmButton);
        
        // CHANGE ALARM SOUND PANEL
        JPanel changePanel = new JPanel();
        changePanel.setBorder(new LineBorder(Color.BLACK, 2));
        changePanel.setLayout(new GridLayout(5,1));
        changePanel.add(new JLabel("Alarm ID:"));
        JTextField alarmID = new JTextField(10);
        changePanel.add(alarmID);
        changePanel.add(new JLabel("New Sound:"));
        JComboBox newSoundSelect = new JComboBox(sounds);
        changePanel.add(newSoundSelect);
        JButton changeAlarmButton = new JButton("Change Alarm");
        changeAlarmButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                params += Integer.parseInt(alarmID.getText()) + "/";
                params += (String)newSoundSelect.getSelectedItem() + "/";
                params += username.getText();
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));

		URL url = new URL("http://localhost:8080/UserService/api/alarm/change_sound/"+params);
		
                System.out.println("http://localhost:8080/UserService/api/alarm/change_sound/"+params);
                
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("PUT");
                
		if (conn.getResponseCode() != 200) {
                        errorLabel.setText("Couldn't change an alarm sound");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        changePanel.add(changeAlarmButton);
        
        // DELETE ALARM PANEL
        JPanel deletePanel = new JPanel();
        deletePanel.setBorder(new LineBorder(Color.BLACK, 2));
        deletePanel.setLayout(new GridLayout(3,1));
        deletePanel.add(new JLabel("Alarm ID:"));
        JTextField dAlarmID = new JTextField(10);
        deletePanel.add(dAlarmID);
        JButton deleteAlarmButton = new JButton("Remove Alarm");
        deleteAlarmButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                params += Integer.parseInt(dAlarmID.getText()) + "/";
                params += username.getText();
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
 
		URL url = new URL("http://localhost:8080/UserService/api/alarm/delete_alarm/"+params);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("DELETE");
                
		if (conn.getResponseCode() != 204) {
                        errorLabel.setText("Alarm with that ID doesn't exist");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        deletePanel.add(deleteAlarmButton);
        
        controlPanel.add(createPanel);
        controlPanel.add(changePanel);
        controlPanel.add(deletePanel);
        JPanel npanel = new JPanel();
        npanel.setLayout(new GridLayout(2,1));
        npanel.add(controlPanel);
        npanel.add(userPanel);
        
        panel.add(npanel);
        //panel.add(userPanel);
        panel.add(alarmList);
        panel.add(errorLabel);
        return panel;
    }
    
    private static JPanel createPlannerPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.BLACK, 2));
        panel.setLayout(new GridLayout(8,1));
        
        JLabel errorLabel = new JLabel("");
        errorLabel.setForeground(Color.red);
        errorLabel.setFont(new Font("Courier", Font.BOLD,12));
        
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new GridLayout(4,1));
        userPanel.add(new JLabel("Username: "));
        JTextField username = new JTextField(50);
        JPasswordField password = new JPasswordField(50);
        userPanel.add(username);
        userPanel.add(new JLabel("Password: "));
        userPanel.add(password);
        
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(1,3));
        DefaultListModel<String> plansListModel = new DefaultListModel<>();
        JList<String> planList = new JList<>(plansListModel);

        // CREATE/GET PLAN PANEL
        JPanel createPanel = new JPanel();
        createPanel.setBorder(new LineBorder(Color.BLACK, 2));
        createPanel.setLayout(new GridLayout(15,1));
        createPanel.add(new JLabel("Date and Time:"));
        JSpinner timeSpinner = new JSpinner( new SpinnerDateModel() );
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "yyyy.MM.dd-HH:mm:ss");
        timeSpinner.setEditor(timeEditor);
        timeSpinner.setValue(new Date());
        timeSpinner.addChangeListener((ChangeEvent e) -> {
            try {
                if (((Date) timeSpinner.getValue()).before(new Date())) {
                    timeSpinner.setValue(new Date());
                    return;
                }
                timeSpinner.commitEdit();
            } catch (ParseException ex) {
                timeSpinner.setValue(new Date());
            }
        });
        createPanel.add(timeSpinner);
        JPanel durationPanel = new JPanel(new GridLayout(1,2));
        createPanel.add(new JLabel("Duration:"));
        JTextField duration = new JTextField(10);
        String[] units = {"d", "h", "m", "s"};
        JComboBox timeUnitSelect = new JComboBox(units);
        durationPanel.add(duration);
        durationPanel.add(timeUnitSelect);
        createPanel.add(durationPanel);
        
        createPanel.add(new JLabel("Name:"));
        JTextField name = new JTextField(50);
        createPanel.add(name);
        
        createPanel.add(new JLabel("Destination:"));
        JTextField dest = new JTextField(50);
        createPanel.add(dest);
        
        JCheckBox setAlarm = new JCheckBox("Set Alarm?");
        createPanel.add(setAlarm);
        
        createPanel.add(new JLabel("Sound:"));
        String[] sounds = {"alarm1.wav", "alarm2.wav", "alarm3.wav"};
        JComboBox soundSelect = new JComboBox(sounds);
        createPanel.add(soundSelect);
        
        createPanel.add(new JLabel("Period:"));
        JTextField period = new JTextField(10);
        createPanel.add(period);
        
        JButton createPlanButton = new JButton("New Plan");
        createPlanButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                Date datetime = (Date)timeSpinner.getValue();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd-HH:mm:ss");  
                params += formatter.format(datetime) + "/";
                params += name.getText().replace(" ", "+") + "/";
                String d = dest.getText().replace(" ", "+").equals("") ? "-" : dest.getText().replace(" ", "+");
                params += d + "/";
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
 
                String unit = (String)timeUnitSelect.getSelectedItem();
                int modifier = 1;
                switch(unit) {
                    case "d":
                        modifier = 86400000;
                        break;
                    case "h":
                        modifier = 3600000;
                        break;
                    case "m":
                        modifier = 60000;
                        break;
                    case "s":
                        modifier = 1000;
                        break;
                }
                
                params += Long.parseLong(duration.getText())*modifier + "/";
                params += setAlarm.isSelected() + "/";
                if (setAlarm.isSelected()) {
                    params += (String)soundSelect.getSelectedItem() + "/";
                    params += Integer.parseInt(period.getText()) + "/";
                } else {
                    params += "-" + "/";
                    params += 0 + "/";
                }
                
                params += username.getText();
                
                System.out.println("http://localhost:8080/UserService/api/planner/create_plan/"+params);
                
		URL url = new URL("http://localhost:8080/UserService/api/planner/create_plan/"+params);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("POST");
                
                System.out.println("UNIT: " + unit);
                
		if (conn.getResponseCode() != 201) {
                        errorLabel.setText("Couldn't create a plan");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        createPanel.add(createPlanButton);
        
        JButton getPlansButton = new JButton("Get Plans");
        getPlansButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));

		URL url = new URL("http://localhost:8080/UserService/api/planner/list_plans/" + username.getText());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("GET");
                
		if (conn.getResponseCode() != 200) {
                        errorLabel.setText("Couldn't fetch plans");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                BufferedReader br = new BufferedReader(new InputStreamReader(
			(conn.getInputStream())));

		String output;
                String plansList = "";
                plansListModel.clear();
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
                    plansList = output;
                }
                
                String[] plans = plansList.split("-");
                
                for (String plan : plans) {
                    plansListModel.addElement(plan);
                }
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        createPanel.add(getPlansButton);
        
        // CHANGE PLAN PANEL
        JPanel changePanel = new JPanel();
        changePanel.setBorder(new LineBorder(Color.BLACK, 2));
        changePanel.setLayout(new GridLayout(16,1));
        
        changePanel.add(new JLabel("Plan ID:"));
        JTextField planID= new JTextField(10);
        changePanel.add(planID);
        
        changePanel.add(new JLabel("Date and Time:"));
        JSpinner newTimeSpinner = new JSpinner( new SpinnerDateModel() );
        JSpinner.DateEditor newTimeEditor = new JSpinner.DateEditor(newTimeSpinner, "yyyy.MM.dd-HH:mm:ss");
        newTimeSpinner.setEditor(newTimeEditor);
        newTimeSpinner.setValue(new Date()); // will only show the current time
        newTimeSpinner.addChangeListener((ChangeEvent e) -> {
            try {
                if (((Date) timeSpinner.getValue()).before(new Date())) {
                    timeSpinner.setValue(new Date());
                    return;
                }
                timeSpinner.commitEdit();
            } catch (ParseException ex) {
                timeSpinner.setValue(new Date());
            }
        });
        changePanel.add(newTimeSpinner);
        JPanel newDurationPanel = new JPanel(new GridLayout(1,2));
        changePanel.add(new JLabel("Duration:"));
        JTextField new_duration = new JTextField(10);
        JComboBox newTimeUnitSelect = new JComboBox(units);
        newDurationPanel.add(new_duration);
        newDurationPanel.add(newTimeUnitSelect);
        changePanel.add(newDurationPanel);
        
        changePanel.add(new JLabel("Name:"));
        JTextField new_name = new JTextField(50);
        changePanel.add(new_name);
        
        changePanel.add(new JLabel("Destination:"));
        JTextField new_dest = new JTextField(50);
        changePanel.add(new_dest);
        
        JCheckBox newSetAlarm = new JCheckBox("Set Alarm?");
        changePanel.add(newSetAlarm);
        
        changePanel.add(new JLabel("Sound:"));
        JComboBox newSoundSelect = new JComboBox(sounds);
        changePanel.add(newSoundSelect);
        
        changePanel.add(new JLabel("Period:"));
        JTextField new_period = new JTextField(10);
        changePanel.add(new_period);
        
        JButton changePlanButton = new JButton("Change Plan");
        changePlanButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                params += Long.parseLong(planID.getText()) + "/";
                Date datetime = (Date)newTimeSpinner.getValue();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd-HH:mm:ss");  
                params += formatter.format(datetime) + "/";
                params += new_name.getText().replace(" ", "+") + "/";
                params += new_dest.getText().replace(" ", "+") + "/";
                
                String unit = (String)newTimeUnitSelect.getSelectedItem();
                int modifier = 1;
                switch(unit) {
                    case "d":
                        modifier = 86400000;
                        break;
                    case "h":
                        modifier = 3600000;
                        break;
                    case "m":
                        modifier = 60000;
                        break;
                    case "s":
                        modifier = 1000;
                        break;
                }
                params += Long.parseLong(new_duration.getText())*modifier + "/";
                params += newSetAlarm.isSelected() + "/";
                if (newSetAlarm.isSelected()) {
                    params += (String)newSoundSelect.getSelectedItem() + "/";
                    params += Integer.parseInt(new_period.getText()) + "/";
                } else {
                    params += "-" + "/";
                    params += 0 + "/";
                }
                
                params += username.getText();
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));

                
		URL url = new URL("http://localhost:8080/UserService/api/planner/change_plan/"+params);
		System.out.println("http://localhost:8080/UserService/api/planner/change_plan/"+params);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("PUT");
                
		if (conn.getResponseCode() != 200) {
                        errorLabel.setText("Couldn't change a plan");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        changePanel.add(changePlanButton);
        
        // DELETE ALARM PANEL
        JPanel deletePanel = new JPanel();
        deletePanel.setBorder(new LineBorder(Color.BLACK, 2));
        deletePanel.setLayout(new GridLayout(3,1));
        deletePanel.add(new JLabel("Plan ID:"));
        JTextField dPlanID = new JTextField(10);
        deletePanel.add(dPlanID);
        JButton deleteAlarmButton = new JButton("Remove Plan");
        deleteAlarmButton.addActionListener((e) -> {
            try {
                errorLabel.setText("");
                String params = "";
                params += Integer.parseInt(dPlanID.getText()) + "/";
                params += username.getText();
                
                String passwordString = new String(password.getPassword());
                String userCredentials = username.getText() + ":" + passwordString;
                String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
                
		URL url = new URL("http://localhost:8080/UserService/api/planner/delete_plan/"+params);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty("Authorization", basicAuth);
                conn.setRequestMethod("DELETE");
                
                System.out.println("http://localhost:8080/UserService/api/planner/delete_plan/"+params);
                
		if (conn.getResponseCode() != 200) {
                        errorLabel.setText("Plan with that ID doesn't exist");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
                
                
		conn.disconnect();

            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        deletePanel.add(deleteAlarmButton);
        
        controlPanel.add(createPanel);
        controlPanel.add(changePanel);
        controlPanel.add(deletePanel);
        JPanel npanel = new JPanel();
        npanel.setLayout(new BorderLayout());
        npanel.add(controlPanel, BorderLayout.NORTH);
        npanel.add(userPanel, BorderLayout.CENTER);
        
        panel.add(npanel);
        //panel.add(userPanel);
        panel.add(planList);
        panel.add(errorLabel);
        return panel;
    }
}
